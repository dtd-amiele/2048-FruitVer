//
//  splashkit_starter.hpp
//  splashkit
//
//  Created by Andrew Cain on 5/10/16.
//  Copyright © 2016 Andrew Cain. All rights reserved.
//

#ifndef splashkit_starter_hpp
#define splashkit_starter_hpp

#define main SPLASHKIT_MAIN

#endif /* splashkit_starter_hpp */
