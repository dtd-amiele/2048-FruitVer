//
// SplashKit Generated Audio C++ Code
// DO NOT MODIFY
//

#ifndef __audio_h
#define __audio_h

#include <string>
#include <vector>
using std::string;
using std::vector;

bool audio_ready();
void close_audio();
void open_audio();

#endif /* __audio_h */
