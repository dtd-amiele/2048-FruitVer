You can place fonts in this folder. Fonts can be otf or ttf files.
